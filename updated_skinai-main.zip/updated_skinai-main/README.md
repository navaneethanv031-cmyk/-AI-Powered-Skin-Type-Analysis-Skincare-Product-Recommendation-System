# SkinAI Premium (Camera + Weekly Diet)

Two-page Flask app with:
- Camera capture + server analysis endpoint (/api/analyze-image) — heuristic demo
- Personalized summary ("Hello {name}…")
- Weekly diet plan by skin type
- Product recommendations by ingredient vs concern

## Run
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000
