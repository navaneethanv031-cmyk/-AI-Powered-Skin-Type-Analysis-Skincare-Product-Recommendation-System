// Camera & image analysis client
const video = document.getElementById('video');
const canvas = document.getElementById('canvas') || document.createElement('canvas');
const startBtn = document.getElementById('startCam');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultBox = document.getElementById('camResult');

const concernsInput = document.getElementById('concerns');
const skinTypeSelect = document.getElementById('skin_type');

async function startCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
    video.srcObject = stream;
  } catch (e) {
    alert('Camera permission denied or unavailable.');
  }
}

function snapBlob() {
  if (!video.videoWidth) { alert('Enable camera first.'); return null; }
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  return new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.9));
}

async function autoAnalyze() {
  const blob = await snapBlob();
  if (!blob) return;
  const fd = new FormData();
  fd.append('image', blob, 'capture.jpg');

  const res = await fetch('/api/analyze-image', { method: 'POST', body: fd });
  if (!res.ok) { resultBox.textContent = 'Analysis failed.'; return; }
  const data = await res.json();
  resultBox.innerHTML = `<div class="p-3 rounded-lg bg-teal-50 border border-teal-200">
    <div class="font-medium">Auto Analysis</div>
    <div>Skin Type: <b>${data.skin_type}</b></div>
    <div>Likely Problem: <b>${data.problem}</b></div>
    ${data.tips?.length ? `<ul class="list-disc ml-5 text-sm mt-1">${data.tips.map(t=>`<li>${t}</li>`).join('')}</ul>`:''}
    <div class="text-xs text-gray-500 mt-1">Not medical advice. For demo only.</div>
  </div>`;

  // Prefill the form with suggestions so the report page uses them
  if (data.skin_type) {
    const index = Array.from(skinTypeSelect.options).findIndex(o => o.value.toLowerCase() === data.skin_type.toLowerCase());
    if (index >= 0) skinTypeSelect.selectedIndex = index;
  }
  if (data.problem) {
    const prev = concernsInput.value.trim();
    if (!prev.toLowerCase().includes(data.problem.toLowerCase())) {
      concernsInput.value = prev ? `${prev}, ${data.problem}` : data.problem;
    }
  }
}

if (startBtn) startBtn.addEventListener('click', startCamera);
if (analyzeBtn) analyzeBtn.addEventListener('click', autoAnalyze);
