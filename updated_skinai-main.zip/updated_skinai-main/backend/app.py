from flask import Flask, render_template, request, jsonify
import json, random, io
import numpy as np

# Use cv2 if available for better analysis; fall back gracefully
try:
    import cv2
    OPENCV_OK = True
except Exception:
    OPENCV_OK = False

app = Flask(__name__, template_folder="templates", static_folder="static")

# ------------------ Load Catalog ------------------
with open("data/products.json", "r", encoding="utf-8") as f:
    PRODUCTS = json.load(f)

# ------------------ Helpers ------------------
def get_weekly_diet(skin_type: str):
    weekly = {
        "oily": {
            "Monday": "Green tea; cucumber & tomato salad; grilled chicken/paneer; avoid fried foods",
            "Tuesday": "Oats + berries; dal + brown rice; steamed veggies",
            "Wednesday": "Spinach-apple smoothie; quinoa salad; sprouts chaat",


            "Thursday": "Curd rice with cucumbers; leafy greens; herbal tea",
            "Friday": "Tomato/spinach soup; multigrain roti + sabzi; nuts",
            "Saturday": "Papaya & watermelon bowl; grilled fish/paneer; lemon water",
            "Sunday": "Detox water; vegetable khichdi; fresh salad"
        },
        "dry": {
            "Monday": "Avocado toast; almonds & walnuts; olive-oil dressed salad",
            "Tuesday": "Lentil soup; chapati; spinach curry",
            "Wednesday": "Oats + banana; walnut & beet salad",
            "Thursday": "Sweet potato mash; dal; green veggies",
            "Friday": "Fish/paneer curry; brown rice; coconut water",
            "Saturday": "Almond smoothie; vegetable pulao; ghee (small)",
            "Sunday": "Coconut water; multigrain chapati; sabzi + curd"
        },
        "sensitive": {
            "Monday": "Ginger tea; spinach paratha; probiotic curd",
            "Tuesday": "Fruit bowl; dal khichdi; beetroot salad",
            "Wednesday": "Green smoothie; grilled veggies; chamomile tea",
            "Thursday": "Pumpkin/carrot soup; chapati; sabzi",
            "Friday": "Turmeric milk; quinoa salad; sprouts",
            "Saturday": "Vegetable upma; herbal tea; hummus + carrots",
            "Sunday": "Lemon water; curd rice; cucumber salad"
        },
        "combination": {
            "Monday": "Idli + sambar; fruit salad",
            "Tuesday": "Poha with peanuts; dal; sabzi",
            "Wednesday": "Chapati; palak paneer; salad",


            "Thursday": "Brown rice; fish/veg curry; buttermilk",
            "Friday": "Vegetable soup; roti; curry",
            "Saturday": "Fruit bowl; multigrain dosa; chutney",
            "Sunday": "Sprouts chaat; herbal tea; curd rice"
        },
        "normal": {
            "Monday": " multigrain dosa; chutney;fruit salad",
            "Tuesday": "Poha with peanuts; dal; sabzi",
            "Wednesday": "Chapati; palak paneer; salad",
            "Thursday": "Brown rice; fish/veg curry; buttermilk",
            "Friday": "Vegetable soup; roti; curry",
            "Saturday": "Fruit bowl;Idli + sambar",
            "Sunday": "Sprouts chaat; herbal tea; curd rice"
        }
    }
    key = (skin_type or "normal").lower()
    return weekly.get(key, weekly["normal"])

def supplement_and_doctor(medical_issues):
    issues = [i.strip().lower() for i in (medical_issues or [])]
    supp = []
    doctor = []
    if "depression" in issues or "anxiety" in issues:
        supp += ["Vitamin D", "Omega-3 (EPA/DHA)"]
        doctor += ["Consider consulting a licensed mental health professional."]
    if "pcod" in issues or "pcos" in issues or "hormonal imbalance" in issues:
        supp += ["Myo-Inositol", "Omega-3"]
        doctor += ["Consult a gynecologist/endocrinologist for hormonal evaluation."]
    if "sensitive skin" in issues or "eczema" in issues:
        supp += ["Probiotics", "Vitamin E"]
        doctor += ["Dermatology consultation recommended for sensitive skin management."]
    return supp, doctor

def recommend_products(user):
    concerns = [c.lower() for c in user.get("concerns", [])]
    skin_type = (user.get("skin_type") or "").lower()
    scored = []
    for p in PRODUCTS:
        score = 0
        ings = " ".join(p.get("ingredients", [])).lower()
        if skin_type and (skin_type in [s.lower() for s in p.get("skin_types", [])] or "all" in [s.lower() for s in p.get("skin_types", [])]):
            score += 1
        if "acne" in concerns and any(k in ings for k in ["salicylic", "benzoyl", "niacinamide", "azelaic"]): score += 2
        if "pigmentation" in concerns and any(k in ings for k in ["vitamin c", "arbutin", "kojic", "licorice"]): score += 2
        if "dryness" in concerns and any(k in ings for k in ["hyaluronic", "ceramide", "glycerin", "squalane"]): score += 2
        if "sensitivity" in concerns and any(k in ings for k in ["centella", "allantoin", "panthenol", "oat"]): score += 2
        scored.append((score, p))
    scored.sort(key=lambda x: x[0], reverse=True)
    recs = [p for s, p in scored[:9]]
    if len(recs) < 6:
        remain = [p for p in PRODUCTS if p not in recs]
        random.shuffle(remain); recs += remain[:6-len(recs)]
    return recs

def build_summary(name, skin_type, concerns, supps, doctors):
    ctext = ", ".join(concerns) if concerns else "no major"
    summary = (f"Hello {name}, we have analyzed that you have a {skin_type} skin type "
               f"with {ctext} problem. We suggest the weekly diet below and also some skincare recommendations.")
    if supps or doctors:
        summary += " "
        if supps: summary += f"Supplements that may help: {', '.join(supps)}. "
        if doctors: summary += " ".join(doctors)
    return summary

# ------------------ Routes ------------------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/report", methods=["POST"])
def report():
    name = request.form.get("name", "User").strip()
    gender = request.form.get("gender", "").strip()
    age = request.form.get("age", "").strip()
    skin_type = request.form.get("skin_type", "normal").strip()
    concerns_csv = request.form.get("concerns", "")
    medical_csv  = request.form.get("medical", "")

    concerns = [c.strip() for c in concerns_csv.split(",") if c.strip()]
    medical_issues = [m.strip() for m in medical_csv.split(",") if m.strip()]

    weekly_plan = get_weekly_diet(skin_type)
    supps, doctors = supplement_and_doctor(medical_issues)
    products = recommend_products({"concerns": concerns, "skin_type": skin_type})
    summary = build_summary(name, skin_type, concerns, supps, doctors)

    return render_template("results.html",
                           name=name, age=age, gender=gender,
                           concerns=", ".join(concerns),
                           summary=summary,
                           weekly_plan=weekly_plan,
                           products=products)

@app.route("/api/analyze-image", methods=["POST"])
def analyze_image():
    """
    Basic heuristic 'analysis' from an uploaded image blob.
    Not a medical diagnosis. Replace with a real ML model later.
    """
    file = request.files.get("image")
    if not file:
        return jsonify({"error": "no_image"}), 400

    data = np.frombuffer(file.read(), np.uint8)

    skin_type = "Normal"
    problem = "None"
    tips = []

    if OPENCV_OK:
        try:
            img = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if img is None:
                raise ValueError("imdecode failed")
            # Resize to manageable size
            small = cv2.resize(img, (256, 256))
            # Brightness proxy
            brightness = float(np.mean(cv2.cvtColor(small, cv2.COLOR_BGR2HSV)[:, :, 2]))
            # Redness proxy
            r_mean = float(np.mean(small[:, :, 2]))
            g_mean = float(np.mean(small[:, :, 1]))
            b_mean = float(np.mean(small[:, :, 0]))
            redness = r_mean - (g_mean + b_mean)/2.0
            # Texture (variance of Laplacian) -> pores/roughness
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            texture = float(cv2.Laplacian(gray, cv2.CV_64F).var())

            # Heuristic mapping
            if brightness < 110:
                skin_type = "Oily"
            elif brightness > 165:
                skin_type = "Dry"
            else:
                skin_type = "Combination"

            if redness > 12:
                problem = "Sensitivity/Redness"
                tips.append("Consider calming products (Centella, Panthenol).")
            elif texture > 140:
                problem = "Acne/Texture"
                tips.append("BHA (Salicylic Acid) 2–% cleanser or toner may help.")
            elif brightness > 170:
                problem = "Dryness"
                tips.append("Use Ceramides + Hyaluronic Acid + Squalane.")
            else:
                problem = "Pigmentation/Spots (est.)"
                tips.append("Vitamin C (AM) + Sunscreen (SPF 50).")

        except Exception:
            skin_type = "Normal"
            problem = "Unknown"
            tips.append("Retake in good lighting, face centered.")

    else:
        # Fallback if OpenCV is not installed
        # Use raw byte mean as a silly proxy
        brightness = float(np.mean(data)) if data.size else 128
        skin_type = "Dry" if brightness > 150 else "Oily"
        problem = "Pigmentation" if brightness > 150 else "Acne"
        tips.append("Install OpenCV for better analysis.")

    return jsonify({
        "skin_type": skin_type,
        "problem": problem,
        "tips": tips
    })

if __name__ == "__main__":
    app.run(debug=True)
